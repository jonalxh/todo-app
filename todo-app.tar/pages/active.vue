<template>
  <h3>Active</h3>
</template>

<script>

export default {
  name: 'ActivePage',
  layout: 'default'
}
</script>