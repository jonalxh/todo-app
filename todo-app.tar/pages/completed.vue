<template>
  <h3>Completed</h3>
</template>

<script>

export default {
  name: 'CompletedPage',
  layout: 'default'
}
</script>