<template>
  <h3>Index</h3>
</template>

<script>


export default {
  name: 'IndexPage',
  layout: 'default'
}
</script>
